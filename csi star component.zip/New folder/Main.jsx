import React from 'react'
import './Main.css';

export const Main = () => {
  return (
    <div className='csi-star-body'>
     <h1>CSI <span>STARS</span></h1>
     <p>We at CSI believe in team family etc etc etc etc etc and to do one and because to foster and that’s why I like to say and is the all.</p>
     <div className='csi-stars'>

        <div className='first-card'>
          <div className='innercards'>
            <img src="./imgs/profilePic.jpg" alt="" />
            <div className='info'>
              <h2>
                Jhanvi Singh
              </h2>
              <h3>Core Member</h3>
              <p>We at CSI believe in team family etc etc etc etc etc and to do one and because to foster and that’s why I like to say and is the all.</p>
              <div className='social'>
                <a href=""><img src="./imgs/instagram (4) 1.png" alt="" /></a>
                <a href=""><img src="./imgs/linkedin 2.png" alt="" /></a>

              </div>
            </div>


          </div>
          <div className='innercards'>
            <div className='info'>
              <h2>
                Jhanvi Singh
              </h2>
              <h3>Core Member</h3>
              <p>We at CSI believe in team family etc etc etc etc etc and to do one and because to foster and that’s why I like to say and is the all.</p>
              <div className='social'>
                <a href=""><img src="./imgs/instagram (4) 1.png" alt="" /></a>
                <a href=""><img src="./imgs/linkedin 2.png" alt="" /></a>

              </div>
            </div>
            <img src="./imgs/profilePic.jpg" alt="" />


          </div>
          <div>
            
          </div>

        </div>
        <div className='cards'>
          <div className='pic'>
          <img src="./imgs/profilePic.jpg" alt="" />
          </div>
          <div className='info'>
              <h2>
                Jhanvi Singh
              </h2>
              <h3>Core Member</h3>
              <p>We at CSI believe in team family etc etc etc etc etc and to do one and because to foster and that’s why I like to say and is the all.</p>
              <div className='social'>
                <a href=""><img src="./imgs/instagram (4) 1.png" alt="" /></a>
                <a href=""><img src="./imgs/linkedin 2.png" alt="" /></a>

              </div>
            </div>
        </div>
        <div className='cards'>
          <div className='pic'>
          <img src="./imgs/profilePic.jpg" alt="" />
          </div>
          <div className='info'>
              <h2>
                Jhanvi Singh
              </h2>
              <h3>Core Member</h3>
              <p>We at CSI believe in team family etc etc etc etc etc and to do one and because to foster and that’s why I like to say and is the all.</p>
              <div className='social'>
                <a href=""><img src="./imgs/instagram (4) 1.png" alt="" /></a>
                <a href=""><img src="./imgs/linkedin 2.png" alt="" /></a>

              </div>
            </div>
        </div>
        <div className='cards'>
          <div className='pic'>
          <img src="./imgs/profilePic.jpg" alt="" />
          </div>
          <div className='info'>
              <h2>
                Jhanvi Singh
              </h2>
              <h3>Core Member</h3>
              <p>We at CSI believe in team family etc etc etc etc etc and to do one and because to foster and that’s why I like to say and is the all.</p>
              <div className='social'>
                <a href=""><img src="./imgs/instagram (4) 1.png" alt="" /></a>
                <a href=""><img src="./imgs/linkedin 2.png" alt="" /></a>

              </div>
            </div>
        </div>
        <div className='cards'>
          <div className='pic'>
          <img src="./imgs/profilePic.jpg" alt="" />
          </div>
          <div className='info'>
              <h2>
                Jhanvi Singh
              </h2>
              <h3>Core Member</h3>
              <p>We at CSI believe in team family etc etc etc etc etc and to do one and because to foster and that’s why I like to say and is the all.</p>
              <div className='social'>
                <a href=""><img src="./imgs/instagram (4) 1.png" alt="" /></a>
                <a href=""><img src="./imgs/linkedin 2.png" alt="" /></a>

              </div>
            </div>
        </div>
     </div>
    </div>
  )
}
